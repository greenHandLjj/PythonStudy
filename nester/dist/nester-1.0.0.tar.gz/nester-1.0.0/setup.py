from distutils.core import setup

setup(
  name = 'nester',
  version = '1.0.0',
  description = '',
  author = 'asuka',
  author_email = '',
  url = '',
  py_modules = ['nester']
)